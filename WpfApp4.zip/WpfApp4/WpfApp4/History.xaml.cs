﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Логика взаимодействия для History.xaml
    /// </summary>
    public partial class History : Window
    {
        private readonly TestBaseEntities1 _db = new TestBaseEntities1(); // Контекст базы данных
        private readonly int _partnerId; // ID партнера

        // Конструктор окна истории покупок
        public History(int partnerId)
        {
            InitializeComponent();
            _partnerId = partnerId;
            LoadPartnerInfo(); // Загрузка информации о партнере
            LoadPurchaseHistory(); // Загрузка истории покупок
        }

        // Загрузка информации о партнере
        private void LoadPartnerInfo()
        {
            var partner = _db.Partners.FirstOrDefault(p => p.ID == _partnerId);
            if (partner != null)
            {
                // Установка заголовка с информацией о партнере
                lblPartnerInfo.Content = $"История покупок: {partner.Наименование_партнера} (ИНН: {partner.ИНН})";
            }
        }

        // Загрузка истории покупок партнера
        private void LoadPurchaseHistory()
        {
            // Получение истории покупок с объединением таблиц
            var history = _db.Partners_product
                .Where(pp => pp.ID_Partner == _partnerId)
                .Join(_db.Product,
                    pp => pp.ID_Product,
                    p => p.ID,
                    (pp, p) => new
                    {
                        ProductName = p.Наименование_продукции,
                        Quantity = pp.Количество_продукции,
                        Date = pp.Дата_продажи,
                        Price = p.Минимальная_стоимость_для_партнера,
                        Sum = pp.Количество_продукции * p.Минимальная_стоимость_для_партнера
                    })
                .OrderByDescending(x => x.Date) // Сортировка по дате (новые сверху)
                .ToList();

            historyListView.ItemsSource = history; // Привязка данных к списку
        }

        // Обработчик нажатия кнопки "Назад"
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow(); // Создание главного окна
            mainWindow.Show(); // Показ главного окна
            Close(); // Закрытие текущего окна
        }
    }
}